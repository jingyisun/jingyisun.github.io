"use strict";

class Boid extends DepthObject {
  constructor(x, y) {
    super();
    this.pos = createVector(x, y);
    this.vel = createVector(random(1, 2), random(-1, 1));
    this.acc = createVector();

    this.freq = random(0.007, 0.017);
    this.amp = random(6, 12);

    this.maxSpeed = 2; // max speed;
    this.maxSteerForce = 0.05; // max steering force

    this.separateDistance = 50;
    this.img = loadImage("data/firefly-8.png");

  }
  
  update() {
    this.vel.add(this.acc);
    this.vel.limit(this.maxSpeed); //***
    this.pos.add(this.vel);
    this.acc.mult(0);
    this.angle = this.vel.heading();
  }
  
  applyForce(force) {
    this.acc.add(force);
  }
  
  flock(boids) {
    var sepaForce = this.separate(boids);
    sepaForce.mult(1.5);
    this.applyForce(sepaForce);
  }
  
  seek(target) {
    var desired = p5.Vector.sub(target, this.pos);
    desired.setMag(this.maxSpeed);
    var steer = p5.Vector.sub(desired, this.vel);
    steer.limit(this.maxSteerForce);
    return steer;
  }
  
  separate(others) {
    var vector = createVector(); // sum for now
    var count = 0;
    for (var i = 0; i < others.length; i++) {
      var other = others[i];
      var distance = this.pos.dist(other.pos);
      if (distance > 0 && distance < this.separateDistance) {
        var diff = p5.Vector.sub(this.pos, other.pos);
        diff.normalize();
        diff.div(distance);
        // let's get the sum!
        vector.add(diff);
        count++;
      }
    }
    // let's get the average
    if (count > 0) {
      vector.div(count);
    }
    if (vector.mag() > 0) {
      // desired velocity
      vector.setMag(this.maxSpeed);
      // steering force
      vector.sub(this.vel);
      vector.limit(this.maxSteerForce);
    }
    return vector;
  }
  
  checkEdges() {
    // x
    if (this.pos.x < 0) {
      this.pos.x = width;
    } else if (this.pos.x > width) {
      this.pos.x = 0;
    }
    // y
    if (this.pos.y < 0) {
      
      this.pos.y = height;
    } else if (this.pos.y > height) {
      this.pos.y = 0;
    }
  }
  
  display() {
    push();
    translate(this.pos.x, this.pos.y);
    var size = sin(frameCount * this.freq) * this.amp;
    imageMode(CENTER);
    image(this.img, 0, 0,size,size);
    pop();
  }
}